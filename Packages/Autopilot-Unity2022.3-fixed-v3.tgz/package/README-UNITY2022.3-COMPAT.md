# Autopilot Unity 2022.3 compatibility package

This is a compatibility repack of the uploaded `com.ramenvr.autopilot` 1.0.1 package.
It is **not an official upstream release** and has not been compiled inside a Unity 2022.3 editor in this environment.

## Changes

- Package minimum Unity version changed from `6000.0` to `2022.3`.
- Package version marked `1.0.1-unity2022.3.0` to distinguish this compatibility build from upstream.
- Declared the package dependencies that the supplied asmdefs reference: Input System 1.7.0, UGUI 1.0.0, TextMeshPro 3.0.6. The existing Mono.Cecil dependency is retained.
- Kept the upstream source and existing Unity-version conditional compilation. The Unity 6.3+ toolbar API remains behind `UNITY_6000_3_OR_NEWER`; Unity 2022.3 uses the legacy UI Toolkit toolbar insertion path.

## Install

1. In Unity 2022.3, open **Window > Package Manager**.
2. Click **+ > Add package from tarball...**.
3. Select `com.ramenvr.autopilot-1.0.1-unity2022.3.0.tgz`.
4. Allow Package Manager to resolve the declared dependencies.
5. Wait for script compilation. If Unity reports errors, copy the **first compiler error** and the full stack/message; do not change the package's `unity` field again as a workaround.

You can also unzip this archive and copy the `package` folder into `Packages/com.ramenvr.autopilot` for an embedded package install.

## Important limitations

- This repack only adjusts package metadata/dependency declarations and relies on APIs believed to exist in Unity 2022.3 (including `FindObjectsByType`, `FindAnyObjectByType`, and `NamedBuildTarget`).
- A real compile and runtime smoke test in Unity 2022.3 is still required. This environment does not contain the Unity Editor, so compatibility cannot honestly be guaranteed.
- Install first in a clean copy or a separate test project, not directly into a production project.
- The bundled Agent Service and account/API requirements are unchanged from upstream.
